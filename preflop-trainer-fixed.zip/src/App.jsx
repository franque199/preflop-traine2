import React from "react";

function App() {
  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
      <h1>Preflop Trainer Básico</h1>
      <p>Projeto base corrigido para Vercel</p>
    </div>
  );
}

export default App;